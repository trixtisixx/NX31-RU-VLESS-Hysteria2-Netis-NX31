@echo off
chcp 65001 >nul
rem NX31-RU: full removal from the router (original DNS settings are restored).
cd /d "%~dp0"
if not exist "NX31-RU.exe" (
  echo NX31-RU.exe не найден. Распакуйте архив NX31-RU полностью.
  pause
  exit /b 1
)
"NX31-RU.exe" uninstall %*
