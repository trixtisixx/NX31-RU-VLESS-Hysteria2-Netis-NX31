@echo off
chcp 65001 >nul
rem NX31-RU: install or update on Netis NX31 (runs NX31-RU.exe from this folder).
rem The server link or subscription URL can be put into nx31-link.txt next to this file.
cd /d "%~dp0"
if not exist "NX31-RU.exe" (
  echo NX31-RU.exe не найден. Распакуйте архив NX31-RU полностью и запустите nx31.bat из распакованной папки.
  pause
  exit /b 1
)
"NX31-RU.exe" %*
